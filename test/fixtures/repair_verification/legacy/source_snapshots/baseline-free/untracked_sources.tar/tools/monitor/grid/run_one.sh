#!/usr/bin/env bash
# run_one.sh <lane> <case> <seed>
# 격자 한 판. 헤드리스 run_demo.jl 을 돌려 요약 JSONL 한 개를 남긴다.
# 요약은 판마다 **다른 파일**이다 — 공용 파일에 append 하면 병렬에서 줄이 섞인다.
set -u
lane=$1; case=$2; seed=$3
ROOT=/home/chahj578/Construction_OODlayer
OUT=${GRID_OUT:?GRID_OUT unset}
tag="${lane}__${case}__s${seed}"
sum="$OUT/sum/$tag.json"
[ -s "$sum" ] && { echo "[skip] $tag"; exit 0; }   # 재개 가능: 이미 있는 판은 안 돈다

# ---- 레인 ----
case "$lane" in
  canonical) L=(DEMO_ROUTER=0 DEMO_POLICY=canonical) ;;
  surrogate) L=(DEMO_ROUTER=0 DEMO_POLICY=surrogate) ;;
  router)    L=(DEMO_ROUTER=1 DEMO_POLICY=canonical) ;;
  *) echo "bad lane $lane" >&2; exit 2 ;;
esac

# ---- 케이스 ----
# 🔴 DEMO_OOD=zone* 은 하드에러다. zone 은 DEMO_ZONE 이라는 **다른 손잡이**로 심는다.
case "$case" in
  battery) C=(DEMO_OOD=battery       DEMO_OOD_SEED=$seed) ;;
  fault)   C=(DEMO_OOD=fault         DEMO_OOD_SEED=$seed) ;;
  zone)    C=(DEMO_OOD=none  DEMO_ZONE=1 DEMO_ZONE_SEED=$seed) ;;
  all3)    C=(DEMO_OOD=fault_battery DEMO_OOD_SEED=$seed DEMO_ZONE=1 DEMO_ZONE_SEED=$seed) ;;
  *) echo "bad case $case" >&2; exit 2 ;;
esac

st=$(date +%s)
timeout "${RUN_TIMEOUT:-1800}" env "${L[@]}" "${C[@]}" \
  DEMO_MODEL=tractor.mpd \
  DEMO_SUMMARY="$sum" \
  MONITOR_STREAM="$OUT/stream/$tag.jsonl" \
  julia +lts --project="$ROOT" "$ROOT/tools/monitor/run_demo.jl" \
  > "$OUT/log/$tag.log" 2>&1
rc=$?
el=$(( $(date +%s) - st ))
# 벽시계는 요약이 아니라 여기서 잰다(요약의 wall_seconds 는 sim 루프만이다).
echo "$tag,$rc,$el" >> "$OUT/wall.csv"
[ $rc -ne 0 ] && echo "[FAIL rc=$rc ${el}s] $tag" || echo "[ok ${el}s] $tag"
exit 0
