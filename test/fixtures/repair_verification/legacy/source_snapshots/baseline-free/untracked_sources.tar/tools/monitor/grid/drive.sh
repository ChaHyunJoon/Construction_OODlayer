#!/usr/bin/env bash
# drive.sh "<lanes>" "<cases>" "<seeds>" <W>
set -u
ROOT=/home/chahj578/Construction_OODlayer
OUT=${GRID_OUT:?}; mkdir -p "$OUT"/{sum,log,stream}
LANES=($1); CASES=($2); SEEDS=($3); W=$4
JOBS="$OUT/jobs_$$.txt"; : > "$JOBS"
# 긴 판을 먼저 넣는다 — 꼬리에 몰리면 풀이 비어도 못 끝난다(all3 > zone > battery > fault).
for c in "${CASES[@]}"; do for l in "${LANES[@]}"; do for s in "${SEEDS[@]}"; do
  echo "$l $c $s" >> "$JOBS"
done; done; done
n=$(wc -l < "$JOBS")
echo "=== grid: $n runs, W=$W, start $(date +%F' '%T) ==="
xargs -P "$W" -L 1 "$ROOT/tools/monitor/grid/run_one.sh" < "$JOBS"
echo "=== done $(date +%F' '%T) — sums=$(ls "$OUT/sum" | wc -l) ==="
