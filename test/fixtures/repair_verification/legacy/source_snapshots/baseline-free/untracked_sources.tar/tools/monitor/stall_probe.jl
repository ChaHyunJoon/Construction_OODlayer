# stall_probe.jl — 정지 탐침(2026-09-21). **관측 전용**이다: 세계를 읽기만 하고 아무것도 안 쓴다.
#
# `STALL_PROBE=1` 일 때 render_demo.jl 이 이 파일을 include 하고 `CB.STALL_PROBE_HOOK[]` 를 채운다.
# 훅은 여섯 시점에서 불린다 — pre_enact · post_body(캐시 재개 앞) · post_enact(재개·재풀이 뒤) ·
# unwedge_pre/post(명목 교착 복구 훅 전후) · stall_onset(무진척 200스텝) · terminate(무진척 종료 직전).
# 한 시점 = JSON 한 줄(`STALL_PROBE_OUT`, 기본 streams/ 옆 `<stream>.stall.jsonl`).
#
# 무엇을 재는가 — 추측이 아니라 **닫힘 조건 그 자체**(route_planning.jl `is_goal(::RobotGo)`):
#   ① 자기 목표 도착  ② 말단이면 false  ③ 다음 노드의 선행 노드가 전부 active/closed
#   ④ 다음이 FormTransportUnit 이면 팀원 전원이 TU 포획거리 안.
# 그리고 zone 판정의 두 기준(수리 사후검사 = 중심점, 채점 = goal_engulfed)과 두 반지름의 출처.

import JSON3

const STALL_PROBE_OUT = Ref{Union{Nothing,String}}(nothing)

_p2(t) = (v = Vector{Float64}(CB.project_to_2d(t.translation)); [v[1], v[2]])
_try(f, d = nothing) = try f() catch; d end
_s(x) = string(x)
# 행 단위 실패는 **메시지를 남긴다** — 조용한 nothing 은 "못 쟀다" 와 "없다" 를 섞는다.
_err(e) = Dict("error" => first(split(sprint(showerror, e), "\n")))

function _member_rows(env, tu)
    st = env.scene_tree
    rows = Any[]
    for (mid, _) in CB.robot_team(tu)
        rn = _try(() -> CB.get_node(st, mid))
        rn === nothing && (push!(rows, Dict("id" => _s(mid), "missing" => true)); continue)
        slot = _try(() -> _p2(CB.global_transform(tu) ∘ CB.child_transform(tu, mid)))
        pos  = _try(() -> _p2(CB.global_transform(rn)))
        rvo  = _try(() -> (p = CB.rvo_get_agent_position(rn); [Float64(p[1]), Float64(p[2])]))
        push!(rows, Dict("id" => _s(mid), "slot" => slot, "scene_pos" => pos, "rvo_pos" => rvo,
            "slot_err" => (slot === nothing || pos === nothing) ? nothing : hypot((slot .- pos)...),
            "captured" => _try(() -> CB.is_within_capture_distance(tu, rn))))
    end
    return rows
end

function _go_row(env, v, n)
    sched, st, cache = env.sched, env.scene_tree, env.cache
    ent = CB.entity(n); id = CB.node_id(ent)
    gl  = _try(() -> CB.global_transform(CB.goal_config(n)))
    es  = _try(() -> CB.global_transform(ent))                        # 스케줄이 보는 로봇/TU 자세
    sn  = _try(() -> CB.get_node(st, id))                             # scene_tree 의 같은 id 노드
    sp  = sn === nothing ? nothing : _try(() -> _p2(CB.global_transform(sn)))
    rvo = sn === nothing ? nothing :
          _try(() -> (p = CB.rvo_get_agent_position(sn); [Float64(p[1]), Float64(p[2])]))
    g   = gl === nothing ? nothing : _p2(gl)
    ep  = es === nothing ? nothing : _p2(es)
    row = Dict{String,Any}("vtx" => v, "type" => _s(nameof(typeof(n))), "id" => _s(id),
        "sched_pos" => ep, "scene_pos" => sp, "rvo_pos" => rvo, "goal" => g,
        "goal_err" => (g === nothing || ep === nothing) ? nothing : hypot((g .- ep)...),
        "at_goal" => (gl === nothing || es === nothing) ? nothing :
                     _try(() -> CB.is_within_capture_distance(es, gl)),
        "terminal" => _try(() -> CB.is_terminal_node(sched, n)),
        "is_goal" => _try(() -> CB.is_goal(n, env)),
        "same_obj_sched_scene" => sn === nothing ? nothing : (sn === ent))
    row["terminal"] === true && return row
    nx = _try(() -> CB.get_node(sched, CB.outneighbors(sched, n)[1]))
    nx === nothing && return row
    nxv = _try(() -> CB.get_vtx(sched, nx))
    row["next"] = Dict{String,Any}("vtx" => nxv, "type" => _s(nameof(typeof(nx.node))),
        "unready_preds" => [Dict("vtx" => u, "type" => _s(nameof(typeof(CB.get_node(sched, u).node))),
                                 "id" => _try(() -> _s(CB.node_id(CB.entity(CB.get_node(sched, u).node)))))
                            for u in CB.inneighbors(sched, nx)
                            if !((u in cache.active_set) || (u in cache.closed_set))])
    if CB.matches_template(CB.FormTransportUnit, nx)
        tu = CB.entity(nx)
        row["next"]["tu"] = _s(CB.node_id(tu))
        row["next"]["tu_pos"] = _try(() -> _p2(CB.global_transform(tu)))
        row["next"]["members"] = _member_rows(env, tu)
    end
    return row
end

function _zone_rows(env)
    zs = collect(values(CB.RESTRICTION_ZONES[]))
    isempty(zs) && return Dict("n_zones" => 0)
    zb = _try(() -> CB.zone_blockage(env))
    navs = Dict(t.vtx => t for t in _try(() -> CB._nav_goal_targets(env), []))
    zc(z) = Vector{Float64}(CB.get_center(z)[1:2])
    rows = Any[]
    # 채점이 막혔다고 한 목표 + zone 근처(3 로봇 반지름 안)의 모든 미완 이동 목표
    near = Set{Int}(b.vtx for b in (zb === nothing ? [] : zb.blocked))
    R = Float64(CB.default_robot_radius())
    for (v, t) in navs, z in zs
        hypot((t.goal .- zc(z))...) < Float64(CB.get_radius(z)) + 3R && push!(near, v)
    end
    for v in sort!(collect(near))
        n = CB.get_node(env.sched, v).node
        t = get(navs, v, nothing)
        g = t === nothing ? _try(() -> _p2(CB.global_transform(CB.goal_config(n)))) : t.goal
        ent = _try(() -> CB.entity(n))
        r_score = t === nothing ? nothing : t.radius                           # zone_blockage 가 쓴 것
        r_solve = _try(() -> Float64(CB.get_radius(CB.get_cached_geom(          # _future_goal_discs 가 쓴 것
                        CB.get_node(env.scene_tree, CB.node_id(ent)), CB.HypersphereKey()))))
        per_zone = [Dict("d" => hypot((g .- zc(z))...), "r_zone" => Float64(CB.get_radius(z)),
                         "center_in" => hypot((g .- zc(z))...) < Float64(CB.get_radius(z)),
                         "engulfed_score" => (t === nothing ? nothing :
                             CB.goal_engulfed(t.goal, t.radius, [z])),
                         "solver_clear" => (r_solve === nothing ? nothing :
                             hypot((g .- zc(z))...) + 1e-9 >= Float64(CB.get_radius(z)) + r_solve + 1e-4))
                    for z in zs]
        push!(rows, Dict("vtx" => v, "type" => _s(nameof(typeof(n))), "id" => ent === nothing ? nothing : _s(CB.node_id(ent)),
                         "goal" => g, "r_score" => r_score, "r_solve" => r_solve,
                         "in_nav_targets" => t !== nothing,
                         "in_solver_discs" => CB.matches_template(CB.EntityGo, n),
                         "blocked_status" => (zb === nothing ? nothing :
                             (bs = [_s(b.status) for b in zb.blocked if b.vtx == v]; isempty(bs) ? nothing : bs[1])),
                         "zones" => per_zone))
    end
    return Dict("n_zones" => length(zs),
                "zones" => [Dict("center" => zc(z), "r" => Float64(CB.get_radius(z))) for z in zs],
                "n_blocked" => zb === nothing ? nothing : zb.n_blocked,
                "n_engulfed" => zb === nothing ? nothing : zb.n_engulfed,
                "n_agent_trapped" => zb === nothing ? nothing : zb.n_agent_trapped,
                "project_blocked" => zb === nothing ? nothing : zb.project_blocked,
                "residual_center" => _try(() -> CB._count_future_goals_in_zone(env)),
                "targets" => rows)
end

function stall_snapshot(env, tag::Symbol; kw...)
    out = STALL_PROBE_OUT[]
    out === nothing && return nothing
    sched, cache = env.sched, env.cache
    gos = Any[]; others = Any[]
    by_robot = Dict{String,Vector{Int}}()
    for v in sort!(collect(cache.active_set))
        n = CB.get_node(sched, v).node
        if CB.matches_template(CB.RobotGo, n) || CB.matches_template(CB.TransportUnitGo, n)
            r = try _go_row(env, v, n) catch e; merge(Dict{String,Any}("vtx" => v), _err(e)) end
            push!(gos, r)
            CB.matches_template(CB.RobotGo, n) && push!(get!(by_robot, get(r, "id", "?"), Int[]), v)
        else
            push!(others, Dict("vtx" => v, "type" => _s(nameof(typeof(n))),
                               "id" => _try(() -> _s(CB.node_id(CB.entity(n))))))
        end
    end
    # 미완 EntityGo 전체의 목표 좌표 — 수리 전 목표+Δ 와 수리 후 목표를 목표별로 대조하는 데 쓴다.
    goals = Dict{String,Any}()
    for v in CB.Graphs.vertices(CB.get_graph(sched))
        v in cache.closed_set && continue
        n = CB.get_node(sched, v).node
        CB.matches_template(CB.EntityGo, n) || continue
        g = _try(() -> _p2(CB.global_transform(CB.goal_config(n))))
        g === nothing || (goals[string(v)] = (_s(nameof(typeof(n))), g))
    end
    rec = Dict{String,Any}("tag" => _s(tag), "kw" => Dict(_s(k) => _s(v) for (k, v) in kw),
        "t" => _try(() -> env.cache.t), "n_closed" => length(cache.closed_set),
        "n_active" => length(cache.active_set), "go" => gos, "active_other" => others,
        "robot_multi_active" => Dict(k => v for (k, v) in by_robot if length(v) > 1),
        "zone" => (try _zone_rows(env) catch e; _err(e) end), "goals" => goals)
    open(out, "a") do io
        JSON3.write(io, rec); println(io)
    end
    println("[stall-probe] ", tag, " closed=", rec["n_closed"], " active=", rec["n_active"],
            " go=", length(gos), " → ", basename(out))
    return nothing
end
