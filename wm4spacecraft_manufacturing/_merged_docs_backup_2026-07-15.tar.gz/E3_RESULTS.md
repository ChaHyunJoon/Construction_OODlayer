# E3 — Closed-Loop Retraining under OOD Drift: Results

**Companion to `PROPOSAL.md` / `EVALUATION.md`** · 2026-07-12 · builds on E1/E2. Script: `e3_drift.py`.

E3 claim (`PROPOSAL.md`): *"active-triggered retraining holds decision quality under OOD drift at ≪
full-retrain cost; a frozen surrogate degrades."* Baselines = frozen surrogate / always-oracle /
periodic-retrain (`EVALUATION.md` Level-4).

## Setup

A **non-stationary stream**: PHASE A = robot-fault OODs (the distribution the surrogate bootstraps on),
then a **DRIFT** into PHASE B where a **novel OOD type** appears — the consequential blocking-zone
(`zoneblk` → ForbidZone). A frozen surrogate has never seen a zone, so it keeps ranking as if every OOD
were a fault (picks Replace) and its decisions become catastrophic. Four policies process the stream
online (decision = best VERIFIED macro, as in E2; regret vs the oracle-best per instance):

- **ORACLE** — verify every macro every step (regret 0, maximal compute): the ceiling.
- **FROZEN** — bootstrap once, never retrain: the do-nothing floor.
- **PERIODIC** — retrain every P steps regardless (spends planner calls even with no drift).
- **ACTIVE (ours)** — verify the surrogate's top-1 each step to get a residual; a **Page-Hinkley/CUSUM
  residual monitor** flags drift; on a flag it **escalates verification** (relabels the drifted
  instances by verifying all their macros) and **retrains** on the buffer, then de-escalates
  (anti-thrash cooldown between retrains).

## Result (stream of 25 steps, drift at step 16; bootstrap 7 faults)

| policy | mean regret (all) | mean regret (post-drift) | planner calls |
|---|---:|---:|---:|
| oracle | 0.000 | 0.000 | 125 |
| **frozen** | 0.360 | **1.000** | 25 |
| periodic | 0.160 | 0.444 | 150 |
| **ACTIVE (ours)** | **0.040** | **0.111** | **57** |

Per-step regret: all policies 0 through phase A; at the drift (step 16) frozen jumps to **1.0 and never
recovers** (picks Replace on every zone), while **ACTIVE spikes for one step, detects the drift,
relabels+retrains, and returns to ~0 by step 17** (time-to-recover ≈ 1 step).

**Headline (E3):** active retraining recovers the near-oracle quality that the frozen surrogate
catastrophically loses (post-drift regret 0.111 vs 1.000), at **57 planner calls vs the oracle's 125
(54% fewer)** and less than periodic's 150 — and periodic still recovers more slowly. The area between
the frozen and active post-drift regret curves is 8.0 (over 9 post-drift steps).

## Interpretation & honest scope

- This is a **genuine distribution shift** (a novel OOD *type*), not a hyperparameter tweak, so the
  frozen collapse is real and the active recovery is meaningful. It also shows why the E2 static
  surrogate is unsafe alone: without the retrain loop it is one drift away from catastrophe.
- The drift here is **abrupt and categorical** (fault → zone). A *gradual* drift (e.g. severity creeping
  across the `zoneblk` overlap range — see `E1_RESULTS.md` §graded, in progress) would exercise the
  monitor's sensitivity/false-alarm tradeoff more finely; the CUSUM parameters (`C_THRESH`, `SLACK`,
  cooldown) are the knobs. The self-check in `e3_drift.py` flags a too-mild drift.
- Compute is counted in **true-planner calls** (each = one full RVO sim + MILP, ~70 s); active spends
  them only to (a) verify its top-1 and (b) relabel briefly at the drift.

## Repro
```
python wm4spacecraft_manufacturing/e3_drift.py wm4spacecraft_manufacturing/oracle/out/e1_dataset.jsonl
```
