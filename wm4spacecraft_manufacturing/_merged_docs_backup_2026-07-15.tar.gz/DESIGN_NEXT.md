# Design: GNN surrogate & Graded Consequential OOD

**2026-07-12** · designs for the two open ingredients after E1–E4 are complete. The GNN is a model
upgrade (gated by the E1 feature-model milestone, which passed); the graded OOD is the one missing piece
that turns the decision task from *easy* (OOD-type ⇒ macro) into a graded ranking with a smooth
quality–compute curve.

---

## 1. GNN surrogate over `(scene tree + schedule DAG)`

### Why
The E1 feature-HistGBR predicts the re-plan outcome from ~13 scalar features (R²≈0.83). It ranks
perfectly on the current easy task, but scalar features throw away the **structure** the true planner
reasons over — which robot is where in the schedule DAG, which transport teams feed which build steps,
how far the disruption propagates. On a *graded/harder* taxonomy (below) that structure is what
separates close candidates. Per `PROPOSAL.md` the feature-model go-signal **gates** this GNN
investment; the signal is met.

### Graph representation (de-risked — all extractable from `env.sched`)
- **Nodes** = schedule DAG vertices. 10 node types confirmed present: `RobotStart, ObjectStart,
  AssemblyComplete, RobotGo, TransportUnitGo, LiftIntoPlace, OpenBuildStep, CloseBuildStep,
  FormTransportUnit, DepositCargo`.
- **Node features**: type one-hot (10) · `t0`,`tF` (scheduled start/end, normalized) · closed/active/future
  flag (from `env.cache.closed_set`/`active_set`) · is-the-OOD-target flag (the faulted robot / the
  blocked assembly / the low-SoC robot) · agent id-hash bucket · staging-circle overlap for zone nodes.
- **Edges** = DAG edges (`Graphs.edges(sched)`), typed by endpoint pair (assignment edge RobotGo→RobotGo,
  precedence, team-membership). Add reverse edges for bidirectional message passing.
- **Global**: the candidate macro (one-hot) + OOD descriptor (kind/severity/spare_count) as a graph-level
  conditioning vector concatenated into readout — so the SAME graph, scored under different macros, gives
  different predictions.

### Architecture (no PyG required — hand-rolled message passing in torch; torch 2.5+CUDA present)
- 3–4 layers of `h_v ← MLP(h_v, Σ_{u∈N(v)} MLP_edge(h_u, e_uv))` (GraphSAGE/GIN-style; relational by
  edge type). Hidden 64–128.
- Readout: attention or mean-pool over nodes → concat the global (macro + OOD) vector → MLP head →
  predict the RunMetrics targets (completion logit, closed-count, realized makespan, min-SoC).
- Loss: **decision-focused** (SPO+/pairwise rank on the per-instance macro ordering), NOT plain MSE —
  the EVALUATION.md value-equivalence point. Keep an MSE aux head for the L0 diagnostic.
- Train an **ensemble (5–10)** for the conformal/uncertainty gate the E2/E3 verify-top-k and drift
  monitor consume.

### Dump seam (the only new Julia work)
Extend `gen_oracle_dataset.jl`'s `capture_features` to also serialize, per instance, the DAG at the OOD
event: `nodes[]` (type, t0, tF, status, flags) + `edges[]` (src, dst, type) as a JSON sub-object. One
graph per instance (shared across its 5 macro rows); the macro is the global conditioning vector. Python
loads it into a torch geometric-style batch. Instance count and graph size are modest (≈300 nodes), so a
single GPU trains in minutes.

### Expected benefit & how it plugs in
Drop-in replacement for `build_model()` in `e1_analyze.py` / `e3` / `e4`. On the current easy task it
also scores regret 0 (so it is *not* a completion blocker — deferred, as documented). Its payoff is
Level-0 accuracy (tighter R², calibrated uncertainty) which **matters once ranking is non-trivial** —
i.e. together with the graded OOD below.

---

## 2. Graded Consequential OOD (turns the step-frontier into a curve)

### The problem it fixes
Every consequential OOD in the current taxonomy has ONE dominant recovery macro (fault→Replace,
zoneblk→ForbidZone), and the admissibility rule removes the ambiguous "should I even intervene?" cases —
so the surrogate's top-1 is always right and the regret-vs-compute frontier is a *step*, not a curve
(E1_RESULTS §caveat). We need instances where the **best macro depends continuously on a state variable**
so ranking near the threshold is genuinely hard.

### Mechanism attempted — zone severity (implemented; EMPIRICALLY did NOT flip)
`place_blocking_zone!(env; offset, rfrac)` exposes two continuous knobs — zone radius as a fraction of
the target staging circle (`rfrac`) and the zone's offset from the staging centre (`offset`). Two
sweeps at seed 1 (`DS_ZFRACS`):

| sweep | values | NOOP | Replace | ForbidZone | oracle-best |
|---|---|---|---|---|---|
| radius `frac` (centred) | 0.5,0.7,0.9,1.1,1.3 | 239 (incomplete) | 239 | **291 (complete)** | ForbidZone — **no flip** |
| `offset` toward core | 0.0,0.5,1.0,1.5,2.0 | 239 (incomplete) | 239 | **291 (complete)** | ForbidZone — **no flip** |

**Finding:** the flip did not appear. NOOP sits at *exactly* 239 across every setting — evidence that in
this tractor layout **any zone placed near a staging area blocks the build** (shrinking it still covers
the centre; offsetting it toward the core just blocks a *different* staging/core region). The build area
is too tightly packed for a "harmless-but-present" zone to exist at these fire points. So zone severity
is **not** a graded knob in this environment — a genuine environmental property, not a tuning miss.

### Working paths forward (ranked by robustness, after 3 physical mechanisms failed to grade)
**Root cause of the difficulty:** each *consequential* OOD in this world has exactly ONE dominant
recovery, and the admissibility rule discards the ambiguous "intervene or not" cases — so within an
admissible instance the best macro is never *close*. Two ways to break that:

1. **★ Cost-aware "intervene-or-not" evaluation (recommended — VALIDATED IN CONCEPT, no environment
   change).** Stop discarding the harmless OODs. Evaluate the realistic decision the operator faces: an
   OOD appeared — do I pay to intervene (Replace/ForbidZone: consumes a spare, churns the schedule, adds
   makespan) or not (NOOP)? Score feasibility-lexicographic with the **adaptation cost** already defined
   in `ood_env_mdp.jl` (`OODRewardCfg`: NOOP 0, Deprioritize 0.3, Replace/ForbidZone/Reform 1.0) as the
   tiebreak among completing macros. **Verified in Python** on the existing dataset + the harmless
   battery instances: the best-macro distribution becomes **{Replace 23, ForbidZone 9, NOOP 2}** — for a
   *harmless* OOD (all macros complete) NOOP wins (intervention is wasted cost), giving a 3rd "restraint"
   decision class. **To finish:** (a) bake the cost-aware ordering into `e1_analyze.py` as a scoring mode;
   (b) generate a *matched* harmless set (small-far zone / mild no-stall battery — already generatable,
   they were only being filtered out by admissibility). This manufactures NOOP-best vs intervene-best
   instances on the existing physics. **Remaining for full non-triviality:** a WITHIN-kind harmless↔
   consequential split (e.g. battery mild→NOOP vs deep-critical→Replace) so `kind` alone can't separate
   them — that still needs the critical-path battery of path (3).
2. **Late-vs-early fault timing** — a very-late fault on a near-done robot lets NOOP complete (loses
   little) while Replace adds churn → best flips to NOOP on the speed axis. Needs the safe-target picker
   relaxed to fire late (current window is closed∈[58,80]).
3. **Battery drain to a *critical-path* robot** — target the drain at a robot whose loss blocks a
   downstream build step (co-tune `shrink`/`ENERGY_W`/target-selection) so deep→Replace vs
   mild→Deprioritize genuinely split (the E1 attempt drained a non-critical robot that spares absorbed).

### Success test
`run_e1_e2.py`'s self-check turns GREEN (frontier no longer flat) when the dataset contains both
NOOP-best and intervene-best admissible instances with a transition region; the surrogate then shows a
small-but-nonzero k=0 regret that verification (k≥1) buys down — the real amortization curve, and the
graded drift that makes E3's monitor sensitivity a live tradeoff.
