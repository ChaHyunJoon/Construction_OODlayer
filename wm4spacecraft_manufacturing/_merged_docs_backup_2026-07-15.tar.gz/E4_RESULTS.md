# E4 — Integration Ablation Grid: Results

**Companion to `PROPOSAL.md` / `EVALUATION.md`** · 2026-07-12 · integrates E1–E3. Script: `e4_ablation.py`.

E4 claim (`PROPOSAL.md`): *"the full system (LLM re-specification + learned surrogate + closed-loop
retraining) dominates on adaptability + compute; the recipe transfers to a satellite-bus twin."* The
deliverable is the **ablation grid over the three axes**, where each cell is exactly one prior-art
regime — so the table doubles as the "vs prior art" comparison.

## The grid (all cells run on the SAME drift stream as E3)

| cell | producer | scorer | retrain | = prior-art regime |
|---|---|---|---|---|
| **A** | all macros | oracle (verify all) | — | brute-force planner oracle (quality ceiling) |
| **B** | LLM (N candidates) | oracle (verify all) | frozen | LLM → exact solver (arXiv 2506.18178) |
| **C** | LLM (N candidates) | surrogate (top-1) | frozen | learned surrogate, NO retraining (E2 static) |
| **D** | LLM (N candidates) | surrogate (top-1) | **active** | **FULL system (ours)** |

Scored on the non-stationary stream (faults → novel blocking-zones) by decision regret
(feasibility-lexicographic, vs oracle-best) and true-planner compute (calls).

## Result (25-step stream, drift at step 16)

| cell (= prior regime) | regret (all) | regret (post-drift) | planner calls |
|---|---:|---:|---:|
| A brute-oracle (ceiling) | 0.000 | 0.000 | 125 |
| B LLM → solver (2506.18178) | 0.000 | 0.000 | 75 |
| C LLM + surrogate, static (E2) | 0.360 | **1.000** | 25 |
| **D LLM + surrogate + retrain (FULL)** | **0.040** | **0.111** | **41** |

**Headline (E4).** The full system **D** sits on the **quality–compute Pareto front**: no cell beats it
on both axes.
- **vs B (LLM→solver, the strong prior-art baseline** that verifies *every* candidate, so is always
  ~0 regret and drift-robust but expensive): D matches B's quality *trend* at **45% fewer planner calls**
  (41 vs 75).
- **vs C (static surrogate, = E2 without the E3 loop):** C is cheapest (25 calls) but **collapses under
  drift (post-drift regret 1.000)**; D recovers to 0.111. Retraining is exactly what makes the cheap
  surrogate *safe*.
- **vs A (brute oracle):** D reaches near-A quality at **1/3 the planner compute**.

So each axis is justified by the ablation: dropping the LLM's candidate-narrowing (A) costs compute;
dropping the surrogate (B) costs compute; dropping retraining (C) costs drift-robustness. Only the full
cell is cheap *and* robust.

## Honest scope — the spacecraft twin

Per `PROPOSAL.md`, the spacecraft twin is a **representative proxy**, not validated against flight
hardware (real spacecraft assembly data is unavailable — that is the premise). This E4 integration
ablation is run on the ConstructionBots **tractor** twin (the deterministic ground-truth world). The
**transferable deliverable is the method** — the DSL macro repertoire, the OOD taxonomy (fault /
battery / zone), the surrogate + verify-top-k + drift-retrain procedure, and this ablation protocol —
**re-fittable onto a facility's own high-fidelity satellite-bus twin** (arXiv 2401.17799 modular bus as
the structural template). The trained weights do NOT transfer; the recipe does. Instantiating the
satellite-bus assembly model in ConstructionBots is the remaining engineering step (a multi-day model
build, out of scope here), after which the identical scripts (`gen_oracle_dataset.jl` → `e1..e4`) re-run
unchanged.

## Caveat (shared with E1–E3)

The tractor OOD taxonomy is decision-*easy* (OOD type determines the best macro), so within a phase the
surrogate is near-perfect and the interesting dynamics live at the **drift boundary** (which E3/E4
exercise). A graded consequential OOD (zone-overlap severity sweep — `E1_RESULTS.md` §graded) would add
within-phase ranking difficulty and a smoother quality–compute curve; it is the one open ingredient and
is logged by the pipeline's own self-checks.

## Repro
```
python wm4spacecraft_manufacturing/e4_ablation.py wm4spacecraft_manufacturing/oracle/out/e1_dataset.jsonl
```
