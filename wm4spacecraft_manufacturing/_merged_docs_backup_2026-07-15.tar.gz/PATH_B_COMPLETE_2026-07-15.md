# PATH B COMPLETE — mid-build fault→Replace now COMPLETES (2026-07-15)

**Result:** the mid-build robot-breakdown Replace, which every prior session left INCOMPLETE (~172–249
/305) and the memory `constructionbots-replace-completion-limit` had declared a *structural* hard
limit, now **COMPLETES the tractor build** — verified **6/6 across 3 seeds × 2 repeats** (closed
275–280, BoundsError=0). The 3-OOD surrogate stream (fault + battery + zone) also completes end-to-end.

---

## What actually fixed it — the pivot

The wedge was chased for many sessions as a *distributed-replace endgame* problem (cyclic OpenBuildStep
dependencies from splitting the faulted robot's tasks across several spares). This session:

1. **Diagnosed it precisely** (B0–B2, engine changes retained as a safety net):
   - `is_goal(TransportUnitGo)` for a stuck carrier failed on `within_goal=true` but
     `next DepositCargo blocked by an OPEN OpenBuildStep` → a **schedule** block, not spatial.
   - Made the carrier rescue *stick*: teleport + pin RVO speed 0 + **force-close via
     `update_planning_cache!(env,0.0)`** (before RVO pushes it back). This closed the Object-17
     keystone (2 carriers force-closed, BoundsError=0) and advanced 200→210 — but a **second-order
     cyclic wedge** (AssemblyID-7 deposit blocked by an OPEN build step, bots double-owing interlocking
     chains) remained. Distributed replace inherently creates these interlocks.

2. **Pivoted to the robust enactment (B4).** The engine already had an **identity-preserving
   scene-tree HOT-SWAP** (`hot_swap_robot!`, `HOT_SWAP_REPLACE` flag, 21/21 unit tests) that keeps the
   faulted robot's `RobotID` and swaps only its physical body from the depot. **No schedule re-stamp →
   the cyclic-OpenBuildStep wedge is structurally impossible** (replan.jl:370 says exactly this). It was
   built earlier but left OFF; the oracle and demos used distributed replace.

   Enacting `ReplaceAgent` via hot-swap makes Replace complete cleanly. A mid-carry victim is healed in
   place (never disbanded), so no `has_edge` crash.

## Changes made this session (ConstructionBots.jl, uncommitted)

- `src/respec/replace_robot.jl` — `force_advance_stuck_carrier!` now **force-closes** a pinned at-goal
  carrier (teleport → RVO pin speed 0 → `update_planning_cache!(env,0.0)`), iterates ALL stuck carriers,
  returns `:carrier_closed` on real progress; enhanced `_carrier_goal_diag` (walks the OPEN-ancestor
  chain: ACTIVE-wait vs OPEN-cycle). [B1]
- `src/respec/replace_robot.jl` — `recover_stalled_teams!` resets `SNAP_COUNT` only on `:carrier_closed`
  (kills the reset-livelock). [B2]
- `src/respec/replan.jl` — reform-recovery path admits `:carrier_closed`/`:carrier_advanced` and
  re-derives the frontier (`reset_cache_resume!`). [B1/B2]
- `tools/demo_respec_replace_anim.jl` — `HOT_SWAP` env hook; `NOPROG` env knob (was hardcoded 30000).
- `tools/demo_surrogate_stream_anim.jl` — `HOT_SWAP` hook (default **ON**); fault event switched to
  `clear=false` so the faulted node survives for hot-swap identity preservation.
- `tools/render_deck_videos.sh` — V4 line passes `HOT_SWAP=1`, `V4_SEED` override (default 3).
- `tools/verify_fault_completion.sh` — B5 multi-seed completion harness (PASS = all COMPLETE, BoundsError=0,
  hot-swap admitted).

wm4spacecraft_manufacturing (uncommitted):
- `oracle/gen_oracle_dataset.jl` — `DS_HOTSWAP` (or `HOT_SWAP`) enacts Replace via hot-swap so fault
  labels are measured in the SAME completing world the demo runs.
- `oracle/run_hotswap_relabel.sh` — B6 scoped driver: regenerate only the tags whose label changes under
  hot-swap (fault_sp3/sp0/faultidle + battery0.05/0.12); mild-battery/zone reused.

## Evidence

- **B5 completion (verify_fault_completion.sh, HOT_SWAP=1):**
  ```
  seed rep  outcome    closed  bounderr  hotswap
   1   1    COMPLETE     280      0        1
   1   2    COMPLETE     276      0        1
   2   1    COMPLETE     280      0        1
   2   2    COMPLETE     275      0        1
   3   1    COMPLETE     280      0        1
   3   2    COMPLETE     275      0        1
   PASS 6/6
  ```
- **B7 3-OOD stream (seed 3):** stream `battery@54 zone@105 fault@139 battery@189` → PROJECT COMPLETE
  (284), 0 planner calls/decision; zone→ForbidZone, fault→Replace→hot-swap(ADMITTED), mild battery→NOOP.

## Why the surrogate story is unchanged (decision-level)

The oracle already labels consequential faults `Replace` (Replace closed more than NOOP even when it
wedged). Hot-swap turns that Replace from INCOMPLETE(~210) into COMPLETE(~280): the **decision is the
same**, the **margin is larger and now feasibility-dominant**. So the 3-OOD surrogate demo works with the
existing surrogate; regenerating labels (B6) only makes the recorded labels honest to the completing world.

## B6 label validation (DS_HOTSWAP=1, seeds 1&2) — the labels are now honest

Per-macro `complete/closed` in the completing world (C = PROJECT COMPLETE):
```
fault_sp3    best=Replace | NOOP:x154 Replace:C291 Depri:x154 Forbid:x154 Reform:x154   <- Replace now COMPLETES (was ~172-210 INCOMPLETE)
fault_sp0    best=Replace | NOOP:x142 Replace:x228 ...   (no spare -> Replace can't fully help; still best, still incomplete)
faultidle    best=NOOP    | all macros C291            (harmless victim -> restraint; Replace wastes a spare)
battery0.05  best=Replace | NOOP:x154 Replace:C291 ...  (deep battery -> Replace COMPLETES)
battery0.12  best=Replace | NOOP:x154 Replace:C291 ...
```
So the completing world yields the correct, feasibility-dominant decision structure: consequential
fault / deep battery -> Replace (complete), harmless fault -> NOOP (restraint), no-spare fault ->
Replace-but-incomplete. On the fault kind the retrained surrogate scores **regret 0.000, top-1 100%**.

### Consistent single-world surrogate (deployed) — `surrogate_hotswap.json`

A naive merge of the hot-swap fault/deep-battery rows with OLD-world mild-battery/zone rows gave a weak
aggregate (Frankenstein of two worlds). Fixed by regenerating **ALL tags under hot-swap** (seeds 1&2,
`run_hotswap_relabel.sh` + `run_graded.sh` fill-in; mild-battery/zone complete fast, no wedge) →
`oracle/out/graded_hs_all.jsonl` (20 instances, 100 rows, single world).

Retrained cost-aware forest at **lambda=15** (the cost weight that keeps the SoC ladder sharp now that
hot-swap makes even a mild-battery Replace *complete*, so only the spare-cost separates it from NOOP):
- **LOO decision-regret 0.100**, fault regret **0.000 (top-1 100%)**, 0 catastrophic.
- Forest per-kind choices show the intended structure: battery → {NOOP×5, Replace×5} (**SoC ladder
  intact**), fault → {Replace×4, NOOP×2}, zone → {ForbidZone×2, NOOP×2}.
- Beats the strong state-blind `always_per_kind` by **+0.636** (paired-bootstrap significant).

Deployed to the demo via `SURROGATE=surrogate_hotswap.json`. Smoke (seed 5) confirms the clean story in
one stream: **fault→Replace(hot-swap), zone→ForbidZone, battery SoC 0.52→NOOP, SoC 0.02→Replace** — the
SoC-ladder flip live — all with 0 planner calls, PROJECT COMPLETE.

### V4 render settings

Re-rendered `results/deck/V4_surrogate_stream.html` with **OOD_SEED=5**, **ANIM_FPS=60** (matches the
V1/V2 deck clips: their 868/1716 keyframes → ~15 s / ~29 s at 60 fps; V4's ~1669 → ~28 s) and the
hot-swap surrogate. `render_deck_videos.sh` V4 line now defaults ANIM_FPS=60 + SURROGATE=hotswap.

## Battery HUD consistency fix (demo integrity)

A deep-battery OOD (e.g. "R15 SoC 0.02 → Replace") was invisible in the live SoC HUD: the injection
drops the robot to 0.02, but the chosen Replace hot-swap calls `_reset_robot_health!` which sets
`fleet.soc = 1.0` within the SAME step, and the HUD snapshots `fleet.soc` once per step (after the
reset) — so 0.02 never lands in a frame, and the target (R13–R22) is scrolled below the visible R1–R12.
The bars then only ever showed the mild-battery/NOOP'd robots (~50%), contradicting the log.

Demo-only fix (no engine change) in `demo_surrogate_stream_anim.jl`:
- `BATT_CRIT` records (robot, post-drop SoC, frame) at each battery injection; before building the HUD,
  the critical SoC is re-injected into `SOC_HISTORY` for a short HOLD (~5% of frames) so the bar visibly
  slams to red before the replacement refills it.
- `_battery_live` now lists any robot that hit ≤0.25 anywhere FIRST, so the deep-battery target is
  visible without scrolling the 22-robot panel.

## Remaining (refinement, not blocking)

- **B6:** run `DS_HOTSWAP=1 bash oracle/run_hotswap_relabel.sh <seed> oracle/out/graded_hs`, merge with the
  existing mild-battery/zone rows, `python export_surrogate.py … --cost-aware`, `e1_analyze.py … --cost-aware`.
  Expected: fault + deep-battery Replace rows flip to COMPLETE; may sharpen the battery decision (the
  smoke's battery@54→ReformTeam blemish).
- Optional: re-render V4 after B6 for the cleanest decision narrative.
