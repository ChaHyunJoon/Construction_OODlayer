# E2 — LLM-over-Surrogate vs LLM-over-Solver: Results

**Companion to `PROPOSAL.md` / `EVALUATION.md`** · 2026-07-12 · builds on `E1_RESULTS.md`.

E2 claim (`PROPOSAL.md`): *"LLM+surrogate matches LLM+solver quality at ≪ planner calls, and explores
more candidates."* Baseline = the prior-art regime **LLM → exact solver** (arXiv 2506.18178): the LLM
proposes candidate macros and each is verified by the true planner.

## Setup (`e2_llm_surrogate.py`)

At each OOD event an **LLM proposes a candidate set** of DSL macros — it reads the event text, so it
knows the OOD *type*, but is uncertain about the exact best response, so it proposes the type's plausible
macros + the do-nothing option + a distractor (`LLM_CANDIDATES`: e.g. fault → {NOOP, Replace,
Deprioritize}, zone → {NOOP, ForbidZone, Replace}). Two ways to pick the winner:

- **LLM → solver (baseline):** verify **every** proposed candidate with the true planner (one full
  RVO sim + MILP each), commit to the best. Cost = |candidates| planner calls; regret 0 by construction.
- **LLM → surrogate (ours):** the learned surrogate ranks the candidates in imagination; verify only
  the **top-k** with the true planner; commit to the best-verified. Cost = k planner calls.

Evaluation is leave-one-instance-out on the oracle dataset (every macro's true outcome is known, so any
candidate set / budget is scored exactly); the surrogate never trains on the held-out instance.

## Result (32 admissible instances; candidate-set size 3)

| policy | planner calls | mean regret |
|---|---:|---:|
| LLM → solver (verify all) | 3.00 | 0.000 |
| **LLM → surrogate (top-1)** | **1.00** | **0.000** |
| LLM → surrogate (top-2) | 2.00 | 0.000 |

**Headline (E2):** LLM→surrogate matches LLM→solver's (zero-regret) decision quality while verifying
only the **top-1** of 3 proposed candidates — **67% fewer true-planner calls at equal decision
quality.** The surrogate's ranking (Level-0 closed-count prediction: R²≈0.82, MAE≈13 nodes — see
`E1_RESULTS.md`) is accurate enough that its top choice is the solver's choice, so the other two
verifications are pure waste the surrogate eliminates.

## Interpretation & honest scope

- This realizes the E2 **amortization** claim: the expensive step (verify a candidate = run the true
  planner) is what the surrogate replaces; the LLM can propose broadly and only its surrogate-top pick is
  actually simulated.
- **Caveat (shared with E1):** the current tractor OOD taxonomy is *decision-easy* — the best macro is
  determined by the OOD type (fault→Replace, zone→ForbidZone), so the surrogate's top-1 is always right
  and the quality–compute curve is a step (regret 0 at k=1). The mechanism and the compute win are real,
  but the **exploration upside** (Level-3: LLM+surrogate over N_large beats LLM+solver over N_small
  because cheap scoring lets it consider more candidates) needs a taxonomy where candidates are *close*
  and ranking is non-trivial. Making an OOD consequential with a graded, response-dependent outcome
  (attempted via battery severity — see `E1_RESULTS.md` §Next; it collapses to Replace or stays harmless
  in this build) is the enabling future work.
- **Self-check built in:** `e2_llm_surrogate.py` flags singleton candidate sets (E2 would collapse to
  E1) and reports when top-1 already matches the solver (the amortization win vs a real tradeoff).

## Repro

```
python wm4spacecraft_manufacturing/e2_llm_surrogate.py wm4spacecraft_manufacturing/oracle/out/e1_dataset.jsonl
```
