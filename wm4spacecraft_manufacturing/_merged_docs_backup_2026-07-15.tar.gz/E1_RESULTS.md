# E1 — Planner-Amortization Surrogate: First-Milestone Results

**Companion to `PROPOSAL.md` / `EVALUATION.md`** · 2026-07-11 · de-risk milestone for E1.

Goal of this milestone (from `PROPOSAL.md` §Resources): *"dump a few-thousand `(state, ood, macro,
metrics)` grid, train a feature-MLP baseline, confirm the surrogate ranks macros in correlation with
truth before investing in the GNN."* This document reports that the pipeline is built and the go/no-go
signal is **GO**.

## Pipeline (built & validated)

1. **Offline dump seam** — `oracle/gen_oracle_dataset.jl`. Generalizes the fixed oracle
   (`gen_oracle_fullsim.jl`) into a dataset generator: for each instance `(OOD kind × severity × seed ×
   spare-provisioning)` it captures the **decision-time state features** (the same public info the
   LLM/surrogate reads) at the studied OOD event, then sweeps every candidate DSL macro `{NOOP, Replace,
   Deprioritize, ForbidZone, ReformTeam}` through the production `run_lego_demo` and records realized
   `RunMetrics` labels. Output: one JSONL row per `(instance, macro)`; a no-fault **control** per
   instance for the admissibility rule. Runs on the fixed oracle harness (genuine real-robot faults,
   realized makespan, full RVO motion stack).
2. **Ranking analysis** — `e1_analyze.py`. Computes the oracle-best macro per instance under
   **feasibility-lexicographic** scoring (completion → closed-nodes → realized makespan), applies the
   **admissibility filter** (keep an instance only if NOOP is strictly worse than its control), and runs
   **leave-one-instance-out** CV: a feature model (HistGradientBoosting) predicts each macro's outcome
   and picks the argmax. Reports top-1 decision regret, NDCG@k, top-k recall, agreement, and
   catastrophic-choice rate against three baselines: `always-<most-common-best>` (state-blind), `random`,
   and `oracle` (regret 0).
3. **Engine support** — added `pre_sim_hook(env)` to `run_lego_demo` (fires after env build, before the
   sim loop; lets the oracle path enable battery / capture pre-sim state without a separate code path).

## Key finding — the OOD taxonomy had to be made *decision-diverse*

The surrogate has something to learn **only if the oracle-best macro varies across instances.** Measured
on the current environment:

- **`fault` → Replace is ALWAYS best** (verified across spare levels 1/2/6 — Replace never loses to
  NOOP; the best macro never flips). A state-blind "always Replace" predictor already scores 0 regret on
  every fault instance.
- **`zone` and `battery` are HARMLESS as shipped** → inadmissible. `random_restriction_zone!`
  deliberately caps the radius to a *local detour obstacle* ("swallowing a goal region deadlocks the
  build"), and battery SoC drops don't stall a robot unless `set_battery_stall!` is enabled. So neither
  changes the outcome vs the control.

⇒ With only `fault` consequential, the ranking task is **degenerate** (always-Replace wins). This is a
real research-infrastructure gap, not a modeling failure.

**Fix — a consequential blocking-zone (a genuine 2nd decision class).** Added `place_blocking_zone!`
(kind `:zoneblk`): it drops a zone **onto a future assembly's staging circle**, so (a)
`zone_blocked_assemblies` returns that assembly ⇒ `ForbidZone` grounds, and (b) the staging is blocked ⇒
NOOP leaves the build incomplete (consequential). Also fixed a latent bug in the shared glue
(`ood_env_mdp.jl`): `zone_blocked_assemblies(env, zone)` was called with `zone` as a 2nd *positional*
arg (the signature takes it as the `zone_keys` **keyword**) → it always errored → `ForbidZone` silently
degenerated to NOOP. With `zone_keys=[zone]`, `ForbidZone` now grounds and **restages the blocked
assembly**, recovering the build. (This also repairs the `:zone` arm of the LLM/RL comparison.)

Seed-1 `zoneblk`: control 291/313 · NOOP/Replace/Deprioritize/ReformTeam **239/313 (incomplete)** ·
**ForbidZone 291/313 (complete)**. Oracle-best = ForbidZone, admissible.

## Result (seeds 1–12 — 32 admissible instances, 2 classes)

Dataset: `oracle/out/e1_dataset.jsonl` (160 rows = 32 instances × 5 macros). Oracle-best distribution:
**Replace ×23** (fault) + **ForbidZone ×9** (zoneblk). Reproduce everything with
`python run_e1_e2.py oracle/out/e1_dataset.jsonl`.

### (a) decision-fidelity (leave-one-instance-out)

| method | mean normalized regret | catastrophic choices |
|---|---:|---:|
| **feature model (state-reading)** | **0.000** | **0 / 32** |
| always-Replace (best state-blind) | 0.281 | 9 / 32 |
| random | 0.844 | 15 / 32 |

Feature model: **NDCG@2 = 1.00, top-1 recall = 1.00, agreement-with-oracle = 1.00.**
**Paired bootstrap 95% CI on the regret reduction (always − model): +0.281 [+0.125, +0.438]** — excludes
0, so the state-reading advantage is significant, not noise.

### (b) Level-0 — the surrogate predicts the OUTCOME, not just a lookup

Held-out **closed-count prediction: MAE = 13.4 nodes** over range [143, 291], **R² = 0.829**. The model
predicts the continuous re-plan outcome well; note it still ranks *perfectly* despite ~13-node
prediction error — the value-equivalence point (`EVALUATION.md` §1): wrong values, right ranking.

### (c) HEADLINE — decision-regret vs true-planner compute (`e1_frontier.py`)

| k (planner calls) | model regret | random-verify regret |
|---:|---:|---:|
| 0 | **0.000** | 0.906 |
| 1 | 0.000 | 0.906 |
| 3 | 0.000 | 0.594 |
| 5 (verify all) | 0.000 | 0.000 |

The surrogate reaches **oracle-quality decisions (regret 0) at 0 planner calls — a 100% compute
reduction** — while a state-blind policy must verify all 5 macros to match it. **Measured wall-clock:
each true-planner label is 69.5 s (MILP assignment + full RVO sim); the oracle spends ~348 s per OOD
decision (5 macros), the surrogate ~0 s.**

**Interpretation.** A state-reading model picks the correct macro per OOD type (regret 0) and predicts
the continuous outcome (R²=0.83), while the best state-blind baseline suffers 0.281 normalized regret and
**9 catastrophic choices** — it picks Replace on every `zoneblk`, where the oracle-best ForbidZone
completes. On the compute axis the surrogate makes the oracle's decision at **0 planner calls (~348 s
saved per OOD)**. E1 is complete: the surrogate reproduces the true planner's decisions at ~0 compute.

**Honest caveat — the task is decision-EASY.** The two classes are separable by the observable OOD type
(fault→Replace, zone→ForbidZone), so the surrogate's top-1 is always right and the regret-vs-compute
frontier is a *step* (regret 0 at k=0), not a graded curve. The compute win is real and shippable, but
the **Level-3 exploration upside** (LLM+surrogate over many candidates beating LLM+solver over few)
needs a taxonomy where candidate outcomes are *close* and ranking is non-trivial. **This was attempted:**
making `battery` consequential (`set_battery_stall!` + `demo_battery_params(shrink)`) — empirically the
stall is absorbed by spares/reform (all macros still complete) or stays harmless, so battery collapses to
Replace or to an inadmissible no-op in this build; it did not yield a graded within-kind class. This is a
genuine property of the tractor environment, logged by the pipeline's own self-checks (`run_e1_e2.py`).

## Next steps (post-E1/E2)

1. **A graded consequential OOD** — the one missing ingredient for a non-trivial frontier. Candidates:
   a *partial* zone block (recoverable by either ForbidZone-restage OR whole-build-translate with
   different makespans), or a battery model whose drain reliably stalls a *critical-path* robot mid-haul
   (needs `shrink`/`ENERGY_W`/target-selection co-tuning — the documented battery trap). Until then the
   frontier is honestly a step, not a curve.
2. **GNN surrogate** — the feature-model milestone (this doc) *gates* the GNN per `PROPOSAL.md`; the
   go-signal is met. A PyG / hand-rolled message-passing GNN over `(scene tree + schedule DAG)` would
   improve Level-0 accuracy (R²) and is the right model once (1) makes ranking non-trivial. On the current
   easy task it would also score regret 0, so it is deferred as the validated next investment, not a
   completion blocker.
3. **E3/E4** — drift-triggered retraining and the spacecraft-twin ablation grid, per `PROPOSAL.md`.

## Files & repro

- `oracle/gen_oracle_dataset.jl` — dump seam (features + per-macro labels + per-label wall-clock).
- `e1_analyze.py` (ranking + L0 + bootstrap), `e1_frontier.py` (compute frontier), `e2_llm_surrogate.py`
  (E2), `run_e1_e2.py` (driver + self-evolving verdict).

```
# regenerate data (per seed; batch <=2 processes to avoid OOM):
cd ConstructionBots.jl
DS_SEEDS=2 DS_KINDS=fault,zoneblk DS_SPARES=1,3 DS_NOPROG=5000 \
  DS_OUT=.../e1_seed2.jsonl julia +lts --project=. ../wm4spacecraft_manufacturing/oracle/gen_oracle_dataset.jl
# concatenate complete-instance seed files -> oracle/out/e1_dataset.jsonl, then:
python wm4spacecraft_manufacturing/run_e1_e2.py wm4spacecraft_manufacturing/oracle/out/e1_dataset.jsonl
```
